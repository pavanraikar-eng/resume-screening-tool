# resume-screening-tool
AI-powered tool that analyzes resumes against job descriptions using NLP. Extracts skills, experience, and provides match scores to streamline recruitment.
